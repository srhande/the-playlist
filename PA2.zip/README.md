# CSE12
Repository for CSE 12 projects
1. PA: The Playlist
2. Description: In this assignment, I designed and implemented a prototype of a music playlist. 
3. Features: We worked on 3 separate files: Song.java, MyPlaylist.java, and MyPlayListIterator.java.
4. Author: Samruddhi Hande, cs12sp19hy
5: Acknowledgements: CSE 12 Tutors, Zybooks
